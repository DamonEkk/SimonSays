#include <stdint.h>

//extern volatile uint8_t pb_debounced_state;

void button_init(void);